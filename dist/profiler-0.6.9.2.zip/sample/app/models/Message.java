package models;

public class Message {

    public String message;

    public Message(String string) {
        this.message = string;
    }

}
